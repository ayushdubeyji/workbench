

### [2026-09-14 18:15:44 UTC] (READING)
Multimeter measured 3.294V on 3V3 rail (stable under 150mA load)

*Tags: multimeter, esp32, power*

---


### [2026-09-14 18:16:53 UTC] (READING)
Multimeter measured 3.294V on 3V3 rail (stable under 150mA load)

*Tags: multimeter, esp32, power*

---


### [2026-09-14 18:19:36 UTC] (READING)
Multimeter measured 3.294V on 3V3 rail (stable under 150mA load)

*Tags: multimeter, esp32, power*

---


### [2026-09-14 18:20:48 UTC] (READING)
Multimeter measured 3.294V on 3V3 rail (stable under 150mA load)

*Tags: multimeter, esp32, power*

---


### [2026-09-14 18:22:04 UTC] (READING)
Multimeter measured 3.294V on 3V3 rail (stable under 150mA load)

*Tags: multimeter, esp32, power*

---


### [2026-09-14 18:22:05 UTC] (READING)
Log reading 5.02V USB bus

---


### [2026-09-14 18:53:22 UTC] (READING)
Measured 3.31V on rail

*Tags: volt,3v3*

---


### [2026-09-14 19:02:44 UTC / Local: 2026-09-14 15:02:44] (READING)
Oscilloscope 1kHz square wave: Vpp=4.96V, duty=50.2%

*Tags: oscilloscope,ne555,signal*

---


### [2026-09-14 19:02:44 UTC / Local: 2026-09-14 15:02:44] (READING)
Log multimeter reading 12.04V on VIN

---
