

### [2026-09-14 18:15:44 UTC] (READING)
Multimeter measured 3.294V on 3V3 rail (stable under 150mA load)

*Tags: multimeter, esp32, power*

---


### [2026-09-14 18:16:53 UTC] (READING)
Multimeter measured 3.294V on 3V3 rail (stable under 150mA load)

*Tags: multimeter, esp32, power*

---


### [2026-09-14 18:19:36 UTC] (READING)
Multimeter measured 3.294V on 3V3 rail (stable under 150mA load)

*Tags: multimeter, esp32, power*

---


### [2026-09-14 18:20:48 UTC] (READING)
Multimeter measured 3.294V on 3V3 rail (stable under 150mA load)

*Tags: multimeter, esp32, power*

---


### [2026-09-14 18:22:04 UTC] (READING)
Multimeter measured 3.294V on 3V3 rail (stable under 150mA load)

*Tags: multimeter, esp32, power*

---


### [2026-09-14 18:22:05 UTC] (READING)
Log reading 5.02V USB bus

---
